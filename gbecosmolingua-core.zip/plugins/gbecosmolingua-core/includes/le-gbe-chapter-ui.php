<?php
/**
 * Composants UI pour les pages chapitre Gbe / Linguistique.
 *
 * @package GbeCosmoLingua_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Bandeau statistiques chapitre.
 *
 * @param array<int, array{value: string, label: string}> $items Stats.
 * @return string
 */
function gbe_chapter_stats( $items ) {
	if ( empty( $items ) ) {
		return '';
	}
	ob_start();
	?>
	<div class="gbe-chapter-stats">
		<div class="gbe-chapter-stats__grid">
			<?php foreach ( $items as $item ) : ?>
				<div class="gbe-chapter-stats__item">
					<p class="gbe-chapter-stats__value"><?php echo esc_html( $item['value'] ); ?></p>
					<p class="gbe-chapter-stats__label"><?php echo esc_html( $item['label'] ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<?php
	return (string) ob_get_clean();
}

/**
 * Navigation ancres in-page.
 *
 * @param array<int, array{id: string, label: string}> $anchors Ancres.
 * @return string
 */
function gbe_chapter_nav( $anchors ) {
	if ( empty( $anchors ) ) {
		return '';
	}

	ob_start();
	echo '<nav class="gbe-chapter-nav" aria-label="' . esc_attr__( 'Sections du chapitre', 'gbecosmolingua-core' ) . '">';
	foreach ( $anchors as $anchor ) {
		echo '<a class="gbe-chapter-nav__tab" href="#' . esc_attr( $anchor['id'] ) . '">' . esc_html( $anchor['label'] ) . '</a>';
	}
	echo '</nav>';

	return (string) ob_get_clean();
}

/**
 * Cartes pays / institutions.
 *
 * @param array<int, array{code: string, title: string, body: string}> $cards Cartes.
 * @return string
 */
function gbe_chapter_country_cards( $cards ) {
	if ( empty( $cards ) ) {
		return '';
	}
	ob_start();
	echo '<div class="gbe-chapter-cards gbe-chapter-cards--countries">';
	foreach ( $cards as $card ) {
		echo '<article class="gbe-chapter-card gbe-chapter-card--country">';
		echo '<span class="gbe-chapter-card__badge" aria-hidden="true">' . esc_html( $card['code'] ) . '</span>';
		echo '<h3 class="gbe-chapter-card__title">' . esc_html( $card['title'] ) . '</h3>';
		echo '<p class="gbe-chapter-card__body">' . esc_html( $card['body'] ) . '</p>';
		echo '</article>';
	}
	echo '</div>';
	return (string) ob_get_clean();
}

/**
 * Cartes pays cliquables (hub vers fiches détaillées).
 *
 * @param array<int, array{code: string, title: string, body: string, url: string, meta?: string}> $cards Cartes.
 * @return string
 */
function gbe_chapter_country_link_cards( $cards ) {
	if ( empty( $cards ) ) {
		return '';
	}

	ob_start();
	echo '<div class="gbe-chapter-cards gbe-chapter-cards--countries gbe-chapter-cards--country-links">';
	foreach ( $cards as $card ) {
		echo '<a class="gbe-chapter-card gbe-chapter-card--country gbe-chapter-card--link" href="' . esc_url( $card['url'] ) . '">';
		echo '<span class="gbe-chapter-card__badge" aria-hidden="true">' . esc_html( $card['code'] ) . '</span>';
		echo '<h3 class="gbe-chapter-card__title">' . esc_html( $card['title'] ) . '</h3>';
		echo '<p class="gbe-chapter-card__body">' . esc_html( $card['body'] ) . '</p>';
		if ( ! empty( $card['meta'] ) ) {
			echo '<p class="gbe-chapter-card__meta">' . esc_html( $card['meta'] ) . '</p>';
		}
		echo '<span class="gbe-chapter-card__cta">' . esc_html__( 'Voir la fiche →', 'gbecosmolingua-core' ) . '</span>';
		echo '</a>';
	}
	echo '</div>';

	return (string) ob_get_clean();
}

/**
 * Frise chronologique des travaux.
 *
 * @param array<int, array{year: string, author: string, title: string, note?: string}> $entries Entrées.
 * @return string
 */
function gbe_chapter_timeline( $entries ) {
	if ( empty( $entries ) ) {
		return '';
	}
	ob_start();
	?>
	<ol class="gbe-chapter-timeline"><?php
	foreach ( $entries as $entry ) {
		echo '<li class="gbe-chapter-timeline__item">';
		echo '<span class="gbe-chapter-timeline__year">' . esc_html( $entry['year'] ) . '</span>';
		echo '<div class="gbe-chapter-timeline__body">';
		echo '<p class="gbe-chapter-timeline__author">' . esc_html( $entry['author'] ) . '</p>';
		echo '<p class="gbe-chapter-timeline__title">' . esc_html( $entry['title'] ) . '</p>';
		if ( ! empty( $entry['note'] ) ) {
			echo '<p class="gbe-chapter-timeline__note">' . esc_html( $entry['note'] ) . '</p>';
		}
		echo '</div></li>';
	}
	?></ol>
	<?php
	return (string) ob_get_clean();
}

/**
 * Cartes références (dictionnaires, synthèses).
 *
 * @param array<int, array{tag: string, title: string, body: string, meta?: string}> $refs      Références.
 * @param string                                                                      $modifier  Modificateur CSS (ex. --refs, --angles).
 * @return string
 */
function gbe_chapter_ref_cards( $refs, $modifier = '--refs' ) {
	if ( empty( $refs ) ) {
		return '';
	}

	$class = 'gbe-chapter-cards gbe-chapter-cards' . $modifier;

	ob_start();
	echo '<div class="' . esc_attr( $class ) . '">';
	foreach ( $refs as $ref ) {
		echo '<article class="gbe-chapter-card gbe-chapter-card--ref">';
		echo '<span class="gbe-chapter-card__tag">' . esc_html( $ref['tag'] ) . '</span>';
		echo '<h3 class="gbe-chapter-card__title">' . esc_html( $ref['title'] ) . '</h3>';
		echo '<p class="gbe-chapter-card__body">' . esc_html( $ref['body'] ) . '</p>';
		if ( ! empty( $ref['meta'] ) ) {
			echo '<p class="gbe-chapter-card__meta">' . esc_html( $ref['meta'] ) . '</p>';
		}
		echo '</article>';
	}
	echo '</div>';

	return (string) ob_get_clean();
}

/**
 * Grille de parlers par pays.
 *
 * @param array<int, array{code: string, title: string, parlers: string[]}> $panels Panneaux.
 * @return string
 */
function gbe_chapter_parler_panels( $panels ) {
	if ( empty( $panels ) ) {
		return '';
	}

	ob_start();
	echo '<div class="gbe-chapter-parlers">';
	foreach ( $panels as $panel ) {
		$count = count( $panel['parlers'] );
		echo '<section class="gbe-chapter-parlers__panel" id="' . esc_attr( sanitize_title( $panel['title'] ) ) . '">';
		echo '<header class="gbe-chapter-parlers__head">';
		echo '<span class="gbe-chapter-card__badge">' . esc_html( $panel['code'] ) . '</span>';
		echo '<h3 class="gbe-chapter-parlers__title">' . esc_html( $panel['title'] ) . '</h3>';
		echo '<span class="gbe-chapter-parlers__count">' . esc_html( sprintf( _n( '%d parler', '%d parlers', $count, 'gbecosmolingua-core' ), $count ) ) . '</span>';
		echo '</header>';
		echo '<ul class="gbe-chapter-parlers__chips">';
		foreach ( $panel['parlers'] as $parler ) {
			echo '<li class="gbe-chapter-parler-chip">' . esc_html( $parler ) . '</li>';
		}
		echo '</ul></section>';
	}
	echo '</div>';

	return (string) ob_get_clean();
}

/**
 * Cartes des sections dialectologiques.
 *
 * @param array<int, array{tag: string, title: string, body: string, examples?: string}> $sections Sections.
 * @return string
 */
function gbe_chapter_dialect_cards( $sections ) {
	if ( empty( $sections ) ) {
		return '';
	}

	ob_start();
	echo '<div class="gbe-chapter-cards gbe-chapter-cards--dialects">';
	foreach ( $sections as $section ) {
		echo '<article class="gbe-chapter-card gbe-chapter-card--dialect">';
		echo '<span class="gbe-chapter-card__tag">' . esc_html( $section['tag'] ) . '</span>';
		echo '<h3 class="gbe-chapter-card__title">' . esc_html( $section['title'] ) . '</h3>';
		echo '<p class="gbe-chapter-card__body">' . esc_html( $section['body'] ) . '</p>';
		if ( ! empty( $section['examples'] ) ) {
			echo '<p class="gbe-chapter-card__meta">' . esc_html( $section['examples'] ) . '</p>';
		}
		echo '</article>';
	}
	echo '</div>';

	return (string) ob_get_clean();
}

/**
 * Panneaux détaillés des sections dialectologiques (innovations + parlers).
 *
 * @param array<int, array{tag: string, title: string, innovations: string[], parlers: string[], body: string}> $sections Sections.
 * @return string
 */
function gbe_chapter_dialect_detail_panels( $sections ) {
	if ( empty( $sections ) ) {
		return '';
	}

	ob_start();
	echo '<div class="gbe-chapter-dialects">';
	foreach ( $sections as $section ) {
		$count   = count( $section['parlers'] );
		$panel_id = sanitize_title( $section['tag'] );

		echo '<section class="gbe-chapter-dialects__panel" id="' . esc_attr( $panel_id ) . '">';
		echo '<header class="gbe-chapter-dialects__head">';
		echo '<span class="gbe-chapter-card__badge">' . esc_html( $section['tag'] ) . '</span>';
		echo '<h3 class="gbe-chapter-dialects__title">' . esc_html( $section['title'] ) . '</h3>';
		echo '<span class="gbe-chapter-dialects__count">' . esc_html( sprintf( _n( '%d parler', '%d parlers', $count, 'gbecosmolingua-core' ), $count ) ) . '</span>';
		echo '</header>';

		if ( ! empty( $section['innovations'] ) ) {
			echo '<h4 class="gbe-chapter-dialects__subtitle">' . esc_html__( 'Innovations phonologiques', 'gbecosmolingua-core' ) . '</h4>';
			echo gbe_chapter_list( $section['innovations'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( ! empty( $section['parlers'] ) ) {
			echo '<p class="gbe-chapter-dialects__parlers-label">' . esc_html__( 'Parlers', 'gbecosmolingua-core' ) . '</p>';
			echo '<ul class="gbe-chapter-parlers__chips">';
			foreach ( $section['parlers'] as $parler ) {
				echo '<li class="gbe-chapter-parler-chip">' . esc_html( $parler ) . '</li>';
			}
			echo '</ul>';
		}

		if ( ! empty( $section['body'] ) ) {
			echo '<p class="gbe-chapter-dialects__body">' . esc_html( $section['body'] ) . '</p>';
		}

		echo '</section>';
	}
	echo '</div>';

	return (string) ob_get_clean();
}

/**
 * Tableau de données (ex. Swadesh).
 *
 * @param array<int, array<string, string>> $rows    Lignes.
 * @param array<int, string>                $headers En-têtes.
 * @return string
 */
function gbe_chapter_data_table( $rows, $headers ) {
	if ( empty( $rows ) || empty( $headers ) ) {
		return '';
	}

	$keys = array_keys( $rows[0] );

	ob_start();
	echo '<div class="gbe-chapter-table-wrap"><table class="gbe-chapter-table"><thead><tr>';
	foreach ( $headers as $header ) {
		echo '<th>' . esc_html( $header ) . '</th>';
	}
	echo '</tr></thead><tbody>';
	foreach ( $rows as $row ) {
		echo '<tr>';
		foreach ( $keys as $key ) {
			echo '<td>' . esc_html( $row[ $key ] ?? '' ) . '</td>';
		}
		echo '</tr>';
	}
	echo '</tbody></table></div>';

	return (string) ob_get_clean();
}

/**
 * Encadré schéma / arbre dialectologique.
 *
 * @param string $schema Texte ASCII.
 * @param string $label  Label accessibilité.
 * @return string
 */
function gbe_chapter_schema_box( $schema, $label = '' ) {
	if ( '' === trim( $schema ) ) {
		return '';
	}
	if ( '' === $label ) {
		$label = __( 'Schéma', 'gbecosmolingua-core' );
	}

	ob_start();
	echo '<div class="gbe-chapter-schema" role="img" aria-label="' . esc_attr( $label ) . '">';
	echo '<pre>' . esc_html( $schema ) . '</pre>';
	echo '</div>';

	return (string) ob_get_clean();
}

/**
 * Liste à puces stylisée (remplace gbe_outline dans les chapitres).
 *
 * @param string[] $items Éléments.
 * @return string
 */
function gbe_chapter_list( $items ) {
	if ( empty( $items ) ) {
		return '';
	}

	ob_start();
	echo '<ul class="gbe-chapter-list">';
	foreach ( $items as $item ) {
		echo '<li>' . esc_html( $item ) . '</li>';
	}
	echo '</ul>';

	return (string) ob_get_clean();
}

/**
 * Pied de chapitre avec liens connexes.
 *
 * @param array<int, array{url: string, label: string}> $links Liens.
 * @return string
 */
function gbe_chapter_footer_links( $links ) {
	if ( empty( $links ) ) {
		return '';
	}
	ob_start();
	?>
	<footer class="gbe-chapter-footer">
		<p class="gbe-chapter-footer__label"><?php esc_html_e( 'Poursuivre la lecture', 'gbecosmolingua-core' ); ?></p>
		<div class="gbe-chapter-footer__links">
			<?php foreach ( $links as $link ) : ?>
				<a class="gbe-chapter-footer__link" href="<?php echo esc_url( $link['url'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a>
			<?php endforeach; ?>
		</div>
	</footer>
	<?php
	return (string) ob_get_clean();
}

/**
 * Contenu chapitre généré à l'exécution (contourne wpautop en base de données).
 *
 * @param WP_Post|null $page Page WordPress.
 * @return string
 */
function gbe_le_gbe_chapter_runtime_content( $page ) {
	if ( ! $page instanceof WP_Post ) {
		return '';
	}

	$uri = get_page_uri( $page );
	if ( ! is_string( $uri ) || '' === $uri ) {
		return '';
	}

	$callbacks = gbe_le_gbe_langue_chapter_callbacks();
	if ( isset( $callbacks[ $uri ] ) && is_callable( $callbacks[ $uri ] ) ) {
		return (string) call_user_func( $callbacks[ $uri ] );
	}

	$callbacks = gbe_le_gbe_linguistique_chapter_callbacks();
	if ( isset( $callbacks[ $uri ] ) && is_callable( $callbacks[ $uri ] ) ) {
		return (string) call_user_func( $callbacks[ $uri ] );
	}

	$callbacks = array(
		'le-gbe/le-continuum-gbe'                            => 'gbe_le_gbe_continuum_content',
		'le-gbe/les-langues'                                 => 'gbe_le_gbe_langues_content',
		'le-gbe/peuples-du-continuum'                        => 'gbe_le_gbe_peuples_content',
		'le-gbe/le-continuum-gbe/inventaire-des-parlers'     => 'gbe_le_gbe_inventaire_parlers_content',
		'le-gbe/le-continuum-gbe/langue-unique'              => 'gbe_le_gbe_langue_unique_content',
		'le-gbe/le-continuum-gbe/pays-et-territoires'        => 'gbe_le_gbe_pays_territoires_content',
		'le-gbe/le-continuum-gbe/regroupement-des-parlers'   => 'gbe_le_gbe_regroupement_parlers_content',
		'le-gbe/le-continuum-gbe/varietes-principales'      => 'gbe_le_gbe_varietes_principales_content',
	);

	if ( ! isset( $callbacks[ $uri ] ) || ! is_callable( $callbacks[ $uri ] ) ) {
		return '';
	}

	return (string) call_user_func( $callbacks[ $uri ] );
}
