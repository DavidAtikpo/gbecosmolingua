<?php
/**
 * Contenu éditorial — potentialités lexicales de Gbe.
 *
 * @package GbeCosmoLingua_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * HTML de la page « Potentialités lexicales de Gbe ».
 *
 * @return string
 */
function gbe_le_gbe_potentialites_lexicales_content() {
	ob_start();
	?>
	<div class="gbe-chapter">
		<p class="gbe-source-note"><em><?php esc_html_e( 'Chapitre — Les potentialités de Gbe : enrichissement lexical, ressources internes, emprunts et combinaisons créatives.', 'gbecosmolingua-core' ); ?></em></p>

		<?php
		echo gbe_chapter_stats( gbe_le_gbe_potentialites_stats() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo gbe_chapter_nav( gbe_le_gbe_potentialites_nav() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		?>

		<section id="generalites" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Généralités', 'gbecosmolingua-core' ); ?></h2>
			<p class="gbe-chapter-section__lead"><?php esc_html_e( 'Les travaux de description scientifique sur Gbe ne manquent plus — l’une des conditions préparatoires à la renaissance linguistique est remplie. Il faut aussi montrer que les conditions d’enrichissement du vocabulaire existent.', 'gbecosmolingua-core' ); ?></p>
			<p><?php esc_html_e( 'Gbe est avant tout une langue monosyllabique : la vaste majorité des lexèmes de base sont de forme (C)V ou (C)V(C). Gbe mobilise plusieurs ressources morphologiques et syntaxiques pour étendre son lexique.', 'gbecosmolingua-core' ); ?></p>
		</section>

		<section id="internes" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Ressources internes', 'gbecosmolingua-core' ); ?></h2>
			<p><?php esc_html_e( 'La plupart des noms monoléxiques ont la structure préfixe + racine (ag-, a-, e-, etc.). D’autres moyens productifs ont été exploités dans les exercices d’expansion lexicale des formes écrites de Gbe.', 'gbecosmolingua-core' ); ?></p>
			<h3><?php esc_html_e( 'Suffixation et dérivation', 'gbecosmolingua-core' ); ?></h3>
			<?php echo gbe_chapter_list( gbe_le_gbe_potentialites_suffixes() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<h3><?php esc_html_e( 'Redoublement, composition et collocations', 'gbecosmolingua-core' ); ?></h3>
			<?php echo gbe_chapter_list( gbe_le_gbe_ressources_internes() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>

		<section id="externes" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Ressources externes', 'gbecosmolingua-core' ); ?></h2>
			<p><?php esc_html_e( 'Gbe emprunte à des langues voisines (Akan, Ga, Yoruba) et européennes (portugais, latin, allemand, français, anglais). La plupart des emprunts respectent les structures phonologiques gbe.', 'gbecosmolingua-core' ); ?></p>
			<?php echo gbe_chapter_ref_cards( gbe_le_gbe_potentialites_emprunts_cards() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<p><?php esc_html_e( 'Les emprunts visuels violent parfois la phonologie gbe ; les emprunts oraux s’intègrent naturellement — traits nouveaux : /r/, voyelles longues, séquences vocaliques adaptées au système tonal.', 'gbecosmolingua-core' ); ?></p>
		</section>

		<section id="combinaisons" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Combinaisons', 'gbecosmolingua-core' ); ?></h2>
			<?php echo gbe_chapter_list( gbe_le_gbe_combinaisons_lexicales() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>

		<section id="conclusion" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Conclusion', 'gbecosmolingua-core' ); ?></h2>
			<p><?php esc_html_e( 'Cette étude confirme que les potentialités créatives de Gbe sont réelles. Comme l’a montré Pazzi (1976) pour le vocabulaire Gen, la structure (C)V offre une combinatoire quasi illimitée.', 'gbecosmolingua-core' ); ?></p>
			<div class="gbe-chapter-callout">
				<p><?php esc_html_e( 'Avec les efforts de standardisation et de modernisation, Gbe acquerra souplesse et stabilité ; son emploi dans toutes les sphères de la vie pourra être positivement encouragé par des mesures adéquates.', 'gbecosmolingua-core' ); ?></p>
			</div>
		</section>

		<?php
		echo gbe_chapter_footer_links( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				array(
					'url'   => '/le-gbe/linguistique/travaux-scientifiques-recents/',
					'label' => __( 'Travaux scientifiques', 'gbecosmolingua-core' ),
				),
				array(
					'url'   => '/le-gbe/linguistique/lexicologie/',
					'label' => __( 'Lexicologie', 'gbecosmolingua-core' ),
				),
				array(
					'url'   => '/le-gbe/linguistique/morphologie/',
					'label' => __( 'Morphologie', 'gbecosmolingua-core' ),
				),
				array(
					'url'   => '/paremiologie/banque-numerique-proverbes/',
					'label' => __( 'Banque de proverbes', 'gbecosmolingua-core' ),
				),
			)
		);
		?>
	</div>
	<?php
	return (string) ob_get_clean();
}

/**
 * @return array<int, array{value: string, label: string}>
 */
function gbe_le_gbe_potentialites_stats() {
	return array(
		array( 'value' => '(C)V', 'label' => __( 'Lexèmes monosyllabiques', 'gbecosmolingua-core' ) ),
		array( 'value' => '10+', 'label' => __( 'Suffixes productifs', 'gbecosmolingua-core' ) ),
		array( 'value' => '5+', 'label' => __( 'Langues emprunteuses', 'gbecosmolingua-core' ) ),
		array( 'value' => '1976', 'label' => __( 'Pazzi — Gen', 'gbecosmolingua-core' ) ),
	);
}

/**
 * @return array<int, array{id: string, label: string}>
 */
function gbe_le_gbe_potentialites_nav() {
	return array(
		array( 'id' => 'generalites', 'label' => __( 'Généralités', 'gbecosmolingua-core' ) ),
		array( 'id' => 'internes', 'label' => __( 'Internes', 'gbecosmolingua-core' ) ),
		array( 'id' => 'externes', 'label' => __( 'Externes', 'gbecosmolingua-core' ) ),
		array( 'id' => 'combinaisons', 'label' => __( 'Combinaisons', 'gbecosmolingua-core' ) ),
		array( 'id' => 'conclusion', 'label' => __( 'Conclusion', 'gbecosmolingua-core' ) ),
	);
}

/**
 * @return string[]
 */
function gbe_le_gbe_potentialites_suffixes() {
	return array(
		__( 'Suffixes productifs : -li (propriétaire), -re (mère), -tɔ (homme), -nu (chose), -gbe (marché), -si (taille/vêtement), -kpɔ (jour/fête)', 'gbecosmolingua-core' ),
		__( 'Exemples : église → églisi (chrétien), banque → bankeli, vendredi → vɛdɛsi', 'gbecosmolingua-core' ),
		__( 'Gen et Waci : -ti (unité/dizaine), -gbe (classe) → blati, alafeti, ayɔli', 'gbecosmolingua-core' ),
	);
}

/**
 * @return array<int, array{tag: string, title: string, body: string}>
 */
function gbe_le_gbe_potentialites_emprunts_cards() {
	return array(
		array(
			'tag'   => 'PT',
			'title' => __( 'Portugais', 'gbecosmolingua-core' ),
			'body'  => __( 'kamisa, mulata, gbegbe, kɔlɔtɔ, banco', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => 'FR/EN',
			'title' => __( 'Français / anglais', 'gbecosmolingua-core' ),
			'body'  => __( 'biki, bɔ̃n, sɛlivili, katon, papiɛ', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => 'Akan',
			'title' => __( 'Akan / arabe', 'gbecosmolingua-core' ),
			'body'  => __( 'apatɔ, sɔsɔ, aléji, alhaji', 'gbecosmolingua-core' ),
		),
	);
}

/**
 * Processus internes de formation des noms.
 *
 * @return string[]
 */
function gbe_le_gbe_ressources_internes() {
	return array(
		'Redoublement de racine monosyllabique (ex. dzadzɔ « chaleur », fefea « fraîcheur »).',
		'Composition simple : deux noms juxtaposés, le second perd son préfixe (ex. wɔnuɖi « chenilles » = wɔnu + ɖi « plein de chenilles »).',
		'Suffixe de nominalisation -i en fin de composition (ex. tɛga « boucle d’oreiller »).',
		'Adjectif + nom (ex. gbɔgbé « maison mère », kɔvivɔn « mauvaise chose »).',
		'Phrases courtes nominalisées (ex. proverbes-surnoms, noms de localités).',
		'Séries verbales coordonnées (ex. kpɔwai « exemple », ɖiɖekɔ « dictionnaire »).',
		'Séries verbales négatives (verbe + mɔ + verbe).',
		'Structure nom + verbe (ex. nuɖuɖu « nourriture étrangère »).',
		'Structure nom + verbe + nom (ex. amewu « meurtre », dɛpɔtɔ « casque »).',
		'Nom + verbe + suffixe (-i, -tɔ, -la).',
		'Symbolisme et onomatopées (ex. kɛsiri « bicyclette », kɛwunka « chaussure à talons »).',
	);
}

/**
 * Types de combinaisons lexicales internes/externes.
 *
 * @return string[]
 */
function gbe_le_gbe_combinaisons_lexicales() {
	return array(
		'Paraphrase endogène de concepts étrangers (ex. ɔ-kekɛ « motocyclette » = feu + bicyclette par symbolisme sonore).',
		'Calques (ex. zinzɔli « président » sur chairman + ngɔ « celui qui reste assis »).',
		'Formations hybrides autochtone + emprunt (ex. xɔxɔtɔ « maison haute » = xɔ + storey).',
		'Réemploi de termes archaïques pour concepts nouveaux (ex. ɖɔkpɛ « octobre », yeɖi « prêtre »).',
		'Extension de sens (ex. bitai « stylo », ananas, raffiné).',
	);
}
