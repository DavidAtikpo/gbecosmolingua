<?php
/**
 * Contenu éditorial — regroupement des parlers gbe (chapitre 7).
 *
 * Classification dialectologique en cinq sections : Vhe, Gen, Ajé, Fono, Phla-Phera.
 * Reconstitué pour GbeCosmoLingua à partir d'un document OCR (H. C. Capo / Gbekɔbu).
 *
 * @package GbeCosmoLingua_Core
 */

defined( 'ABSPATH' ) || exit;

/**
 * HTML de la page « Regroupement des parlers gbe ».
 *
 * @return string
 */
function gbe_le_gbe_regroupement_parlers_content() {
	ob_start();
	?>
	<div class="gbe-chapter">
		<p class="gbe-source-note"><em><?php esc_html_e( 'Chapitre 7 — Un regroupement des parlers Gbe : méthodologie dialectologique et cinq sections du continuum.', 'gbecosmolingua-core' ); ?></em></p>

		<?php
		echo gbe_chapter_stats( gbe_le_gbe_regroupement_stats() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo gbe_chapter_nav( gbe_le_gbe_regroupement_nav() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		?>

		<section id="generalites" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Généralités', 'gbecosmolingua-core' ); ?></h2>
			<p class="gbe-chapter-section__lead"><?php esc_html_e( 'Après l’historique des formes écrites et l’inventaire des parlers (chapitre 1), ce chapitre pose le problème de la viabilité des graphies actuelles et propose un regroupement linguistique rigoureux.', 'gbecosmolingua-core' ); ?></p>
			<p><?php esc_html_e( 'Les contours dialectaux des formes écrites restent flous : l’objectif est de montrer comment les parlers identifiés se regroupent en sections sur la base de leurs affinités phonologiques et de leur histoire commune (proto-Gbe).', 'gbecosmolingua-core' ); ?></p>
		</section>

		<section id="antecedents" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Notes sur les tentatives antérieures', 'gbecosmolingua-core' ); ?></h2>
			<p><?php esc_html_e( 'Les études antérieures reconnaissaient des parlers apparentés, mais les classifications restaient vagues — surtout géographiques, avec des critères d’intelligibilité plutôt que strictement linguistiques.', 'gbecosmolingua-core' ); ?></p>
			<?php echo gbe_chapter_ref_cards( gbe_le_gbe_regroupement_antecedents() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<div class="gbe-chapter-callout">
				<p><?php esc_html_e( 'D’où l’insuffisance de ces tentatives pour un regroupement dialectologique rigoureux — et la nécessité d’une méthode fondée sur les innovations phonologiques.', 'gbecosmolingua-core' ); ?></p>
			</div>
		</section>

		<section id="methodologie" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Méthodologie de regroupement', 'gbecosmolingua-core' ); ?></h2>
			<p><?php esc_html_e( 'Une classification linguistique doit partir de l’inventaire des parlers, les décrire, puis les regrouper selon leurs degrés d’affinité et leur histoire commune.', 'gbecosmolingua-core' ); ?></p>
			<?php echo gbe_chapter_ref_cards( gbe_le_gbe_regroupement_niveaux_analyse(), '--angles' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<p><?php esc_html_e( 'Cette étude privilégie les innovations phonologiques non conditionnées, complétées par les conditionnées et morphophonologiques, interprétées à partir de la reconstruction du proto-Gbe. La syntaxe et la sociolinguistique sont prises en compte marginalement.', 'gbecosmolingua-core' ); ?></p>
		</section>

		<section id="sections" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Regroupement proposé : cinq sections', 'gbecosmolingua-core' ); ?></h2>
			<p><?php esc_html_e( 'Chaque section est définie par des innovations phonologiques partagées et un noyau de parlers mutuellement intelligibles.', 'gbecosmolingua-core' ); ?></p>
			<?php echo gbe_chapter_dialect_detail_panels( gbe_le_gbe_regroupement_dialect_sections() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>

		<section id="schema" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Schéma du regroupement', 'gbecosmolingua-core' ); ?></h2>
			<?php
			echo gbe_chapter_schema_box( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				gbe_le_gbe_regroupement_schema(),
				__( 'Arbre dialectologique du continuum Gbe', 'gbecosmolingua-core' )
			);
			?>
		</section>

		<section id="conclusion" class="gbe-chapter-section">
			<h2><?php esc_html_e( 'Conclusion', 'gbecosmolingua-core' ); ?></h2>
			<?php echo gbe_chapter_ref_cards( gbe_le_gbe_regroupement_conclusions(), '--refs' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<div class="gbe-chapter-callout">
				<p><?php esc_html_e( 'La différence avec Pazzi (1979) relève de divergences méthodologiques : son regroupement part de l’histoire des populations ; celui-ci part de l’histoire des parlers eux-mêmes. Ce regroupement est linguistiquement justifié et complète l’inventaire du chapitre 1.', 'gbecosmolingua-core' ); ?></p>
			</div>
		</section>

		<?php
		echo gbe_chapter_footer_links( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				array(
					'url'   => '/le-gbe/le-continuum-gbe/inventaire-des-parlers/',
					'label' => __( 'Inventaire des parlers', 'gbecosmolingua-core' ),
				),
				array(
					'url'   => '/le-gbe/le-continuum-gbe/langue-unique/',
					'label' => __( 'Gbe, une langue unique', 'gbecosmolingua-core' ),
				),
				array(
					'url'   => '/le-gbe/linguistique/dialectologie/',
					'label' => __( 'Dialectologie', 'gbecosmolingua-core' ),
				),
				array(
					'url'   => '/le-gbe/linguistique/travaux-scientifiques-recents/',
					'label' => __( 'Travaux scientifiques', 'gbecosmolingua-core' ),
				),
			)
		);
		?>
	</div>
	<?php
	return (string) ob_get_clean();
}

/**
 * Statistiques du regroupement.
 *
 * @return array<int, array{value: string, label: string}>
 */
function gbe_le_gbe_regroupement_stats() {
	return array(
		array(
			'value' => '5',
			'label' => __( 'Sections dialectales', 'gbecosmolingua-core' ),
		),
		array(
			'value' => '4',
			'label' => __( 'Niveaux d’analyse', 'gbecosmolingua-core' ),
		),
		array(
			'value' => '50+',
			'label' => __( 'Parlers classés', 'gbecosmolingua-core' ),
		),
		array(
			'value' => 'Proto',
			'label' => __( 'Base : proto-Gbe', 'gbecosmolingua-core' ),
		),
	);
}

/**
 * Navigation in-page.
 *
 * @return array<int, array{id: string, label: string}>
 */
function gbe_le_gbe_regroupement_nav() {
	return array(
		array(
			'id'    => 'generalites',
			'label' => __( 'Généralités', 'gbecosmolingua-core' ),
		),
		array(
			'id'    => 'antecedents',
			'label' => __( 'Antécédents', 'gbecosmolingua-core' ),
		),
		array(
			'id'    => 'methodologie',
			'label' => __( 'Méthodologie', 'gbecosmolingua-core' ),
		),
		array(
			'id'    => 'sections',
			'label' => __( 'Sections', 'gbecosmolingua-core' ),
		),
		array(
			'id'    => 'schema',
			'label' => __( 'Schéma', 'gbecosmolingua-core' ),
		),
		array(
			'id'    => 'conclusion',
			'label' => __( 'Conclusion', 'gbecosmolingua-core' ),
		),
	);
}

/**
 * Cartes classifications antérieures.
 *
 * @return array<int, array{tag: string, title: string, body: string}>
 */
function gbe_le_gbe_regroupement_antecedents() {
	return array(
		array(
			'tag'   => '1890',
			'title' => 'Ellis',
			'body'  => __( 'Cinq dialectes : Plaxo, Fon, Phla, Adja-Fon, Awlan.', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => '1938',
			'title' => 'Manoukian',
			'body'  => __( 'Huit variantes : Aja, Gen, Gun, Phelé, Fon, Waci, Weme, Awlan-Tewun.', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => '1952',
			'title' => 'Westermann & Bryan',
			'body'  => __( 'Isolent Gen, Fon, Awlan, Gun, Aja — classification géographique.', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => '1910',
			'title' => 'Westermann / Ansre',
			'body'  => __( 'Trois sections : occidentale (Mina, Awlan), centrale (Gen, Agome), orientale (Glin, Fon, Maxi).', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => '1951',
			'title' => 'Riebstein',
			'body'  => __( 'Awlangbe, Gengbe/Mina, Fongbe (Fon propre + Gun/Alada).', 'gbecosmolingua-core' ),
		),
	);
}

/**
 * Quatre niveaux d’analyse des innovations.
 *
 * @return array<int, array{tag: string, title: string, body: string}>
 */
function gbe_le_gbe_regroupement_niveaux_analyse() {
	return array(
		array(
			'tag'   => 'i',
			'title' => __( 'Vocabulaire', 'gbecosmolingua-core' ),
			'body'  => __( 'Niveau le plus changeant — difficile à mesurer objectivement pour le regroupement.', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => 'ii',
			'title' => __( 'Syntaxe', 'gbecosmolingua-core' ),
			'body'  => __( 'Structures universelles — peu révélatrice des affinités dialectales.', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => 'iii',
			'title' => __( 'Morphologie', 'gbecosmolingua-core' ),
			'body'  => __( 'Utile via la morphophonologie — complément de la phonologie.', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => 'iv',
			'title' => __( 'Phonologie', 'gbecosmolingua-core' ),
			'body'  => __( 'Innovations non conditionnées = indices les plus sûrs pour l’histoire commune — privilégiées ici.', 'gbecosmolingua-core' ),
		),
	);
}

/**
 * Panneaux des cinq sections dialectologiques.
 *
 * @return array<int, array{tag: string, title: string, innovations: string[], parlers: string[], body: string}>
 */
function gbe_le_gbe_regroupement_dialect_sections() {
	return array(
		array(
			'tag'          => 'Vhe',
			'title'        => __( 'Dialectes Vhe', 'gbecosmolingua-core' ),
			'innovations'  => gbe_le_gbe_innovations_vhe(),
			'parlers'      => gbe_le_gbe_section_vhe(),
			'body'         => __( 'Section occidentale (Westermann 1910), avec Waci. Intercompréhension quasi totale. Awlan = dialecte prestigieux, base de l’Éwé standard ; Waci écrit coexiste avec l’Éwé écrit. Adangbe est un dialecte Vhe (Sprigge 1967).', 'gbecosmolingua-core' ),
		),
		array(
			'tag'          => 'Gen',
			'title'        => __( 'Dialectes Gen', 'gbecosmolingua-core' ),
			'innovations'  => gbe_le_gbe_innovations_gen(),
			'parlers'      => gbe_le_gbe_section_gen(),
			'body'         => __( 'Intercompréhension à 100 % ; tous les locuteurs disent parler Gengbe. Gliji, Agwe et Anexo sont des « accents » plus que des variantes distinctes — plaque tournante du continuum.', 'gbecosmolingua-core' ),
		),
		array(
			'tag'          => 'Ajé',
			'title'        => __( 'Dialectes Ajé', 'gbecosmolingua-core' ),
			'innovations'  => gbe_le_gbe_innovations_aje(),
			'parlers'      => gbe_le_gbe_section_aje(),
			'body'         => __( 'Intercompréhension totale entre Hwe, Dogbé, Stédé ; quasi-totale avec Sikpi. L’Aja écrit repose sur Dogbé et Hwe.', 'gbecosmolingua-core' ),
		),
		array(
			'tag'          => 'Fono',
			'title'        => __( 'Dialectes Fono', 'gbecosmolingua-core' ),
			'innovations'  => gbe_le_gbe_innovations_fono(),
			'parlers'      => gbe_le_gbe_section_fono(),
			'body'         => __( 'Intercompréhension quasi totale. Gun écrit coexiste avec le Fon écrit. Les Gun et les Fono tendent à s’exclure sociologiquement (Fongbe = Danxomegbe).', 'gbecosmolingua-core' ),
		),
		array(
			'tag'          => 'Phla-Phera',
			'title'        => __( 'Dialectes Phla-Phera', 'gbecosmolingua-core' ),
			'innovations'  => gbe_le_gbe_innovations_phla_phera(),
			'parlers'      => gbe_le_gbe_section_phla_phera(),
			'body'         => __( 'Groupe conventionnel — territoire non continu. Différences lexicales importantes, moins phonologiques. Alada se distingue nettement des Fon (préfixes nominaux).', 'gbecosmolingua-core' ),
		),
	);
}

/**
 * Cartes de conclusion par section.
 *
 * @return array<int, array{tag: string, title: string, body: string}>
 */
function gbe_le_gbe_regroupement_conclusions() {
	return array(
		array(
			'tag'   => 'Vhe',
			'title' => __( 'Unité ressentie', 'gbecosmolingua-core' ),
			'body'  => __( 'Awlan = base de l’Éwé standard (cf. Stewart, Pahn).', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => 'Gen',
			'title' => __( 'Haut prestige', 'gbecosmolingua-core' ),
			'body'  => __( 'Conscience forte d’unité (Gengbe) — cf. Pazzi « langue Gen ».', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => 'Ajé',
			'title' => __( 'Conscience d’unité', 'gbecosmolingua-core' ),
			'body'  => __( 'Correspond à « langue Ajatɔ » de Pazzi (hors Saxwe, Se).', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => 'Fono',
			'title' => __( 'Homogène', 'gbecosmolingua-core' ),
			'body'  => __( 'Entités sociologiques distinctes (Gun vs Fono).', 'gbecosmolingua-core' ),
		),
		array(
			'tag'   => 'Phla-Phera',
			'title' => __( 'Label conventionnel', 'gbecosmolingua-core' ),
			'body'  => __( 'Pazzi parle plutôt de langues Ayizo, Saxwe, Xwela.', 'gbecosmolingua-core' ),
		),
	);
}

/**
 * Innovations phonologiques des dialectes Vhe.
 *
 * @return string[]
 */
function gbe_le_gbe_innovations_vhe() {
	return array(
		'Fricatives bilabiales /ɸ/ et /β/ à partir des fricatives labio-vélaires du proto-Gbe',
		'Convergence des voyelles mi-fermée et mi-ouverte du proto-Gbe en /e/ ou /ɛ/ selon les dialectes',
		'Sonantes vélaires /j/ et /w/ à partir de *w et *h du proto-Gbe',
		'Convergence de la pharyngale sonore et de la sonante labio-vélaire en /w/',
		'Développement des aspirées alvéolaires en occlusives laminales /tʃ/ et /dʒ/',
		'Au plus deux préfixes nominaux réguliers : a-/e- et l-/n- (ou d-/n-)',
	);
}

/**
 * Innovations phonologiques des dialectes Gen.
 *
 * @return string[]
 */
function gbe_le_gbe_innovations_gen() {
	return array(
		'Occlusive bilabiale sourde /p/ à partir de *kp du proto-Gbe',
		'Développement de /w/ en /w/ devant voyelles antérieures, /wɔ/ ou /nw/ devant postérieures',
		'Innovation de /oj/ et /uj/ à partir de *y du proto-Gbe',
		'Simplification des affriquées alvéolaires en fricatives /s/ et /z/',
		'Convergence des aspirées et occlusives laminales en /tʃ/ et /dʒ/',
		'Séquences *ty/*dy et *ky/*gy développées en /tʃ/ et /dʒ/',
		'Convergence des voyelles *o et *u en /u/',
		'Suites vocaliques *ei, *oi, *ai, *ui réalisées /we/, /oe/, /e/',
	);
}

/**
 * Innovations phonologiques des dialectes Ajé.
 *
 * @return string[]
 */
function gbe_le_gbe_innovations_aje() {
	return array(
		'Convergence *ts/*dz et *tʃ/*dʒ en /s/ et /z/',
		'Développement de *tn/*dn en /tʃ/ et /dʒ/',
		'Séquences *ty/*dy et *ky/*gy en /tʃ/ et /dʒ/',
		'Palatalisation de /t/ et /d/ devant voyelles fermées en /c/ et /j/',
		'Variantes chuintantes [ʃ] et [ʒ] de /s/ et /z/ devant voyelles fermées',
		'Convergence *hw et *kw en /w/',
		'Convergence *i et *ɨ en [i]',
		'Simplification des suites vocaliques dans les nominaux et verbaux',
	);
}

/**
 * Innovations phonologiques des dialectes Fono.
 *
 * @return string[]
 */
function gbe_le_gbe_innovations_fono() {
	return array(
		'Convergence *ts/*th/*s et *dz/*dh/*z en /s/ et /z/',
		'Développement de /oj/ et /uj/ à partir de *ty/*dy et *ky/*gy',
		'Convergence *hw et *kw en /kw/',
		'Maintien de l’opposition entre *i et *ɨ',
		'Préfixes nominaux e-/a- et l-/n- (ou ɛ-/a-)',
		'Suites vocaliques réalisées de façon spécifique (ei→e, oi→o, etc.)',
	);
}

/**
 * Innovations phonologiques des dialectes Phla-Phera.
 *
 * @return string[]
 */
function gbe_le_gbe_innovations_phla_phera() {
	return array(
		'Évolution *ts/*dz en /s/ et /z/',
		'Développement variable de *tn/*dn vers /s/, /z/ ou /t/, /d/',
		'Convergence *hw, *kw et *ɣw en /kw/',
		'Maintien de l’opposition *i vs *ɨ',
		'Au moins trois préfixes nominaux : e-, a-, l-/n- (et variantes d-, ɛ-)',
	);
}

/**
 * Parlers de la section Vhe.
 *
 * @return string[]
 */
function gbe_le_gbe_section_vhe() {
	return array(
		'Awlan',
		'Awlangben',
		'Gbin',
		'Peci',
		'Kpindo',
		'Dayin',
		'Vé',
		'Avéno',
		'Tewun',
		'Vhlin',
		'Fodome',
		'Kpelen',
		'Agu',
		'Vo',
		'Hó',
		'Waci',
		'Wancé',
		'Adangbe',
	);
}

/**
 * Parlers de la section Gen.
 *
 * @return string[]
 */
function gbe_le_gbe_section_gen() {
	return array(
		'Gliji',
		'Agwe',
		'Anexo',
	);
}

/**
 * Parlers de la section Ajé.
 *
 * @return string[]
 */
function gbe_le_gbe_section_aje() {
	return array(
		'Hwe',
		'Dogbé',
		'Stédé',
		'Sikpi (quasi-total)',
	);
}

/**
 * Parlers de la section Fono.
 *
 * @return string[]
 */
function gbe_le_gbe_section_fono() {
	return array(
		'Kpase',
		'Archin',
		'Agbome',
		'Gun',
		'Maxi',
		'Weme',
	);
}

/**
 * Parlers de la section Phla-Phera.
 *
 * @return string[]
 */
function gbe_le_gbe_section_phla_phera() {
	return array(
		'Tsapha',
		'Kotafon',
		'Ayizo',
		'Tèvi',
		'Phelé',
		'Phla',
		'Alada',
	);
}

/**
 * Schéma ASCII du regroupement dialectal.
 *
 * @return string
 */
function gbe_le_gbe_regroupement_schema() {
	return <<<'SCHEMA'
                        GBE (proto)
                            |
        +---------+---------+---------+---------+
        |         |         |         |         |
       Vhe       Gen       Ajé      Fono   Phla-Phera
        |         |         |         |         |
   Awlan, Peci  Gliji,   Dogbé,   Kpase,  Tsapha,
   Waci, Hó…    Agwe,    Hwe,     Gun,    Kotafon,
                Anexo    Stédé    Agbome  Ayizo…
SCHEMA;
}
